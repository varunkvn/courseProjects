//Heading displayed on the quiz page
pageHeading = "History Quiz"

//Questions

qa = new Array()

qa[0] = new Question("Who was the first president of the United States?", "George Washington", "Abraham Lincoln" , "Benjamin Franklin", "Harry Truman", 0)
		
qa[1] = new Question("When did Columbus discover America?", "1249", "1942", "1492", "1294", 2)

qa[2] = new Question("Who commanded the Macedonian army?", "Napoleon", "Alexander the Great", "Cleopatra", "George Patton", 1)

qa[3] = new Question("Where did Davy Crockett lose his life?", "The Spanish Inquisition", "The Alamo", "Miami, Florida", "On the Oregon Trail", 1)

qa[4] = new Question("Who was the first man to walk on the moon?", "Louis Amstrong", "Buzz Amstrong", "Jack Amstrong", "Neil Amstrong", 3)
