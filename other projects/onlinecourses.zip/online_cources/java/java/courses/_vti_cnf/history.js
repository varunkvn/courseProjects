vti_encoding:SR|utf8-nl
vti_author:SR|yusuf
vti_modifiedby:SR|yusuf
vti_timecreated:TR|20 Aug 2001 07:23:07 -0000
vti_timelastmodified:TR|20 Aug 2001 08:09:35 -0000
vti_backlinkinfo:VX|
vti_extenderversion:SR|4.0.2.2717
vti_nexttolasttimemodified:TR|20 Aug 2001 07:47:29 -0000
