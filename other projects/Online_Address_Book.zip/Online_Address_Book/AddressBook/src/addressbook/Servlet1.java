package addressbook;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;
import java.sql.*;

public class Servlet1 extends HttpServlet {
  private static final String CONTENT_TYPE = "text/html";

  //Initialize global variables
  public void init() throws ServletException {
  }

  //Process the HTTP Get request
  String ho="";
  String ha="";
  public void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    response.setContentType(CONTENT_TYPE);
    PrintWriter out = response.getWriter();
    String s=request.getParameter("user");
    out.println("Print on servlet  "+s);
    searchDetail(s,response);


   HttpSession session=request.getSession();
   session.setAttribute("u",ho);
   session.setAttribute("uu",ha);
   response.sendRedirect("http://localhost:8080/WebModule1/jsp1.jsp");
  }

  public void searchDetail(String sname, HttpServletResponse response){

   try {
     PrintWriter out = response.getWriter();
     Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
     Connection con = DriverManager.getConnection("jdbc:odbc:dsn","","");
     Statement st = con.createStatement();
     ResultSet rs = st.executeQuery("select * from record where name='"+sname+"' ");
     while (rs.next()) {
      // System.out.println(rs.getString("name"+"    "+"phone"+"    "+"address"));

      ho=rs.getString("phone");
      ha=rs.getString("address");

      System.out.println(ho);
      System.out.println(ha);
    }
  }
    catch (Exception ex) { }
   }

  //Clean up resources
  public void destroy() {
  }
}
