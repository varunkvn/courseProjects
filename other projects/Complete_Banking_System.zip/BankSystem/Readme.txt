-----------------------------------
Release Notes

BankSystem [Pvt] Limited.
-----------------------------------

(c) 2003 Muhammad Wasif Javed
	  
--------
Overview
--------

This Program is for those who not only want to keep their Records
but they want to keep their Bank Balance updated too. This is the
Best Program for them. It is very easy to use as it is totaly GUI
[Graphical User Interface] based application.

-------------------
System Requirements
-------------------

To Use Mubarik Arts System You must Need The Following

1 :- Pentium II OR Higher
2 :- Java Development Kit 1.2 [1.3 Recommended]
3 :- MS WINDOWS 98 OR Higher
4 :- 64MB Ram [128MB Recommended]
5 :- VJA [A Good Company VGA So Programs Interface Show Nicely]

--------------
How To Run
--------------

It is easy to Run BankSystem. Just set path of your Java Folder
in Dos Prompt and then type "Java BankSystem" and press Enter Key.
(I've made this Program on MSWindows 98 and it works very nicely on
it). If You Face any Problem Then Contact to Author of BankSystem.

-------
Caution
-------

While trying to close the active form it may throw an exception
if u r using java 1.2. Print option of the BankSystem work nice
& quick if Printer attach with the same computer on which Program
is running otherwise it may take a while.

--------------
Contact Author
--------------

For Any Kind of Help E-mail me.

wasi_javed@hotmail.com