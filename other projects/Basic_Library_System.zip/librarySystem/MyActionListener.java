import java.awt.event.*;

public class MyActionListener implements FocusListener
{
   public void focusGained(FocusEvent e)
   {
   	}
	
	
	public void focusLost(FocusEvent e)

{
	
	}
	
}