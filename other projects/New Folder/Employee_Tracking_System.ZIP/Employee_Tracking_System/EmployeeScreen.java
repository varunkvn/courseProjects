
package frm.employee;

public class EmployeeScreen
{

        public static void main(String args[])
        {
     	new employee();
		}    	
}    