

public class msg_box
JTextArea outputArea;
String output="";
{

   public msg_box()
   {
   	
    output_Message();
   	
   }  
  
   public void getMessageArea(String )
}