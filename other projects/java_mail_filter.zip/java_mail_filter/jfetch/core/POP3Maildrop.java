
package jfetch.core;

public class POP3Maildrop extends Maildrop {
    
    public POP3Maildrop() {
    }

    protected int getDefaultPort() {
        return 110;
    }
    
} // POP3Maildrop
