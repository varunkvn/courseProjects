DNS Name: Library
Databasename:Library.mdb in database folder


Just goto the folder LibraryMgt where u extracted the zip file.
type java Logon there and the login screen appears.

To login at admin screen select admin and use the following username and passwd.

Admin  username: Admin	
password	: admin

For members and clerks u can create them and login with respective ids afterwards.

I assert again that the GUI is not my own and my compliements to Md. Wasif.

