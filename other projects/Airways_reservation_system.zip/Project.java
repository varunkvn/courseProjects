import java.awt.*;
import java.awt.event.*;
public class Project extends Frame
{
public static void main(String args[])
{

Login L = new Login();
L.setLocation(200,100);
L.setSize(300,300);
L.setVisible(true);
L.setTitle("Login Screen");
}
}